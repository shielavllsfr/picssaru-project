import React, { useState, useEffect } from "react";
import Navigation from "../components/Navigation";
import firebase from "../utils/firebase";
import {
  makeStyles,
  Avatar,
  IconButton,
  Button,
  TextareaAutosize,
  Grid,
} from "@material-ui/core";
import Modal from "@material-ui/core/Modal";
import Backdrop from "@material-ui/core/Backdrop";
import Fade from "@material-ui/core/Fade";
import AddAPhotoIcon from "@material-ui/icons/AddAPhoto";

export default function Dashboard() {
  const [user, setUser] = useState({ email: "" });

  useEffect(() => {
    var user = firebase.auth().currentUser;
    if (user) {
      setUser(user);
    } else {
    }
  }, []);

  const useStyles = makeStyles((theme) => ({
    modal: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: "2px solid #000",
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      minWidth: "40%",
      maxWidth: "40%",
      maxHeight: "60%",
      minHeight: "60%",
    },
  }));

  const classes = useStyles();
  const [open, setOpen] = React.useState(false);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Navigation />
      <Button type="button" onClick={handleOpen}>
        <Avatar alt={user.email} src="/static/images/avatar/1.jpg" />
      </Button>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        className={classes.modal}
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <div className={classes.paper}>
            <h2 id="transition-modal-title">Create New Post</h2>
            <p id="transition-modal-description"></p>
            <Grid>
              <IconButton>
                <AddAPhotoIcon />
              </IconButton>
            </Grid>

            <Grid>{/* DITO MAGDIDISPLAY YUNG IUUPLOAD NA IMAGE */}</Grid>

            <Grid>
              <TextareaAutosize
                rowsMax={4}
                aria-label="maximum height"
                placeholder="Write a Caption"
              />
            </Grid>
          </div>
        </Fade>
      </Modal>
    </div>
  );
}
